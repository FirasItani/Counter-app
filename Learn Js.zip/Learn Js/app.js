

//intialize count 0
//listen for click on the incerment
//increment count var

//change count-el in html to reflect the new count




let countEL = document.getElementById("count-el")
let saveEL = document.getElementById("save-el")
let count = 0
let countStr = ''

function increment() {
  count += 1
  countEL.innerText = count
}


function save() {
  countStr = count + ' - '
  saveEL.textContent += countStr
  count = 0
  countEL.textContent = 0
}

function decrement() {
  count -= 1
  countEL.innerText = count
}
